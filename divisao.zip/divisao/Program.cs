﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace divisao
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, resultado;

            Console.WriteLine("insira o primeiro numero");
            n1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("insira o segundo numero");
            n2 = Convert.ToInt32(Console.ReadLine());

            resultado = n1 / n2;

            Console.WriteLine(resultado);

            Console.ReadKey();
        }
    }
}
